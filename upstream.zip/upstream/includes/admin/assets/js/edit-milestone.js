(function ($) {
    setTimeout(function () {
        $('#_upstream_milestone_project_id').select2();
        $('#_upstream_milestone_assigned_to').select2();
    }, 1000);
})(jQuery);
