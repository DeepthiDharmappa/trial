<?php
/**
 * UpStream_Model_ArgumentException
 *
 * @package UpStream
 */

/**
 * Class UpStream_Model_ArgumentException
 */
class UpStream_Model_ArgumentException extends Exception {
	// silent is golden.
}
