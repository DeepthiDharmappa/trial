<?php
/**
 * Do not put custom translations here. They will be deleted on UpStream updates.
 *
 * Keep custom UpStream translations in /wp-content/languages/upstream/
 */
